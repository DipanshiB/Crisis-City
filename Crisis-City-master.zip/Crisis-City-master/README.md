GITHUB REPO FOR HACK THE CRISIS INDIA

Basic Setup done.

Components :
Leaderboard - to be added, to be used for each game separate
Dashboard - to be added for each user; can be changed to a page component

Games :
2048 added - needs to be updated @Ishita
Mario - to be added 

Pages :
Homepage - will contain signin via google funcitonality - to be added
//login and signup can be removed entirely

Quiz : to be added, can be added to components

Amey changed readme!